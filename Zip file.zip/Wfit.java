class Wfit
{
	static void worstfit(int memsize[],int m,int processSize[],int n)
	{
		int allocation[]=new int [n];
		int temp;
		
		for(int i=0;i<allocation.length;i++)
			allocation[i]=-1;
		
		
		for(int i=0;i<m;i++)
		{
			for(int j=i+1;j<m;j++)
			{	
				if(memsize[i]<memsize[j])
				{				
					temp=memsize[i];
					memsize[i]=memsize[j];
					memsize[j]=temp;
				}
			}
		}		

		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				if(memsize[j]>=processSize[i])
				{
					allocation[i]=j;
					memsize[j]=processSize[i];
					break;
				}
			}
		}

		System.out.println("\nProcess No.\tProcess Size\tMemory no.");
		for (int i=0;i<n;i++)
		{
			System.out.print(" " + (i+1) + "\t\t" + processSize[i] + "\t\t");
			if (allocation[i] != -1)
				System.out.print(allocation[i] + 1);
			else
				System.out.print("Not Allocated");
			System.out.println();
		}
	} 

	public static void main(String [] args)
	{
		int memsize[]={100,500,200,300,600};
		int processSize[]={112,415,215,476};
		int a=memsize.length;
		int b=processSize.length;
		worstfit(memsize,a,processSize,b);
		
	}

	
}
