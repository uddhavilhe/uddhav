public class msg
{  
   static
   {
      System.loadLibrary("message"); 
   }
 
   private native void sayHello();

   public static void main(String[] args)
  {
      new msg().sayHello();
   }
}
