#include<iostream>
using namespace std;
class fcfs
{
        
    public:
             int job;
            
             int Arrival[10],Burst[10],Wt[10],TAT[10],CT[10];
             int temp;
             fcfs()
             {
                  cout<<"Enter the how many jobs do you want:";
                  cin>>job;
                  for(int i=0;i<job;i++)
                  {
                      cout<<"Enter Arrival time of job j"<<i+1<<" : "<<endl;
                      cin>>Arrival[i];
                      cout<<"Enteer Burst time:"<<endl;
                      cin>>Burst[i];
                  }
             }
             void display();
             void sort();
             void operation();
};
void fcfs::operation()
{
   //sort();
   Wt[0]=0;TAT[0]=0;CT[0]=0;
   for(int i=0;i<job;i++)
   {
       TAT[i]=Burst[i]+Wt[i];
       CT[i]=Burst[i]+TAT[i-1];
       Wt[i+1]=Burst[i]+Wt[i];
   }
}      
   
void fcfs::sort()
{
     for(int i=0;i<job;i++)
     {
         for(int j=i+1;j<job;j++)
         {
             if(Arrival[i]>Arrival[j])
             {
                  temp=Arrival[i];
                  Arrival[i]=Arrival[j];
                  Arrival[j]=temp;
             }
         } 
     }
}    
   
void fcfs::display()
{
    cout<<"Job name\t"<<"Arrival time\t"<<"Burst time\t"<<"Waiting\t"<<"TAT\t"<<"CT"<<endl;
    for(int i=0;i<job;i++)
    {
        cout<<"j"<<i+1<<"\t\t"<<Arrival[i]<<"\t\t"<<Burst[i]<<"\t\t"<<Wt[i]<<"\t"<<TAT[i]<<"\t"<<CT[i]<<endl;
    }
}

int main()
{
    fcfs b;
    b.operation();
    b.display();
    return 0;
}
