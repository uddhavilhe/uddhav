import java.util.*;

class prad
{    int job;
           String name[] = new String[50];
        int a[]=new int[50];  
        int Arrival[]=new int[50];
        int Burst[]=new int[50];
        int Wt[]=new int[50];
        int TAT[]=new int[50];
        int CT[]=new int[50];
        int temp;
         
   
   prad()
   { 
    Scanner sc=new Scanner(System.in);
      System.out.println("enter no of jobs");
       job=sc.nextInt();
    
    
    for(int i=0;i<job;i++)
     {
      System.out.println("enter the name of job");
      name[i] = System.console().readLine();
      System.out.println("enter the arrival time");
      Arrival[i]=sc.nextInt();

      System.out.println("enter the burst");
      Burst[i]=sc.nextInt();
                  
     }
    
   } 

public void sort()
{
     for(int i=0;i<job;i++)
     {
         for(int j=i+1;j<job;j++)
         {
             if(Arrival[i]>Arrival[j])
             {
                  temp=a[i];
                  a[i]=a[j];
                  a[j]=temp;
             }
         } 
     }
}    

public void opt()
{
  sort();
   Wt[0]=0;TAT[0]=Burst[0];CT[0]=Burst[0];
   for(int i=1;i<job;i++)
   {
        Wt[i] = (Arrival[i - 1] + Burst[i - 1]
                 + Wt[i - 1]) - Arrival[i];
       TAT[i]=Burst[i]+Wt[i];
       CT[i]=CT[i-1]+Burst[i];
       //Wt[i]=Burst[i-1]+Wt[i-1];
   }
}      

public void display()
{
    opt();
    System.out.println("Job name\t"+"Arrival time\t"+"Burst time\t"+"Waiting\t"+"CT\t"+"TAT");
    for(int i=0;i<job;i++)
    {
        System.out.println(name[i]+"\t\t"+Arrival[i]+"\t\t"+Burst[i]+"\t\t"+Wt[i]+"\t"+CT[i]+"\t"+TAT[i]);
    }
}
public void avg()
{
System.out.println("average of waiting time is=");
int sum=0;
for(int i=0;i<job;i++){
sum=sum+Wt[i];
}

float average=(float)sum/job;
System.out.println(average);

System.out.println("average of TAT time is=");
int sumT=0;
for(int i=0;i<job;i++){
sumT=sumT+TAT[i];
}

float averageT=(float)sumT/job;
System.out.println(averageT);
}

   public static void main(String s[])   
   {
     prad p=new prad();
     p.sort();
     p.opt();
     p.display();
p.avg();
   }
}





























