#include<iostream>
using namespace std;
class process
{
    private:
                int job;
                struct ps
                {
             	    string Name;
             	    int Arrival,Burst,Wt,TAT,CT;    
                };

    public:
             struct ps a[50],temp;
             process()
             {
                  cout<<"Enter the how many jobs do you want:";
                  cin>>job;
                  for(int i=0;i<job;i++)
                  {
                      cout<<"Enter job name:"<<endl;
                      cin>>a[i].Name;
                      cout<<"Enter Arrival time:"<<endl;
                      cin>>a[i].Arrival;
                      cout<<"Enteer Burst time:"<<endl;
                      cin>>a[i].Burst;
                  }
             }
             void display();
             void sort();
             void operation();
};
void process::operation()
{
   sort();
   a[0].Wt=0;a[0].TAT=0;a[0].CT=0;
   for(int i=0;i<job;i++)
   {
       a[i].TAT=a[i].Burst+a[i].Wt;
       a[i].CT=a[i].Burst+a[i-1].TAT;
       a[i+1].Wt=a[i-1].CT-a[i].Arrival;
   }
}      
   
void process::sort()
{
     for(int i=0;i<job;i++)
     {
         for(int j=i+1;j<job;j++)
         {
             if(a[i].Arrival>a[j].Arrival)
             {
                  temp=a[i];
                  a[i]=a[j];
                  a[j]=temp;
             }
         } 
     }
}    
   
void process::display()
{
    operation();
    cout<<"Job name\t"<<"Arrival time\t"<<"Burst time\t"<<"Waiting\t"<<"TAT\t"<<"CT"<<endl;
    for(int i=0;i<job;i++)
    {
        cout<<a[i].Name<<"\t\t"<<a[i].Arrival<<"\t\t"<<a[i].Burst<<"\t\t"<<a[i].Wt<<"\t"<<a[i].TAT<<"\t"<<a[i].CT<<endl;
    }
}

int main()
{
    process b;
  b.display();
    return 0;
}
